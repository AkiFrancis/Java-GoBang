import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.DataOutputStream;
import java.io.IOException;

public class Startover_Button_Listener implements ActionListener, GoBang_Consts {
    public void setDataOutputStream(DataOutputStream dataOutputStream) {
        this.dataOutputStream = dataOutputStream;
    }

    private DataOutputStream dataOutputStream;

    private final Chess_Board_Listener board_listener = GoBang_Consts.board_listener;
    private final Chess_Utils chess_utils = new Chess_Utils();

    @Override
    public void actionPerformed(ActionEvent e) {
        if (board_listener.getOffline_flag()) {
            if (JOptionPane.showConfirmDialog(null, "请确定重新开始本局", "提示", JOptionPane.YES_NO_OPTION) == 0) {
                chess_utils.start_over();
            }
        } else if(board_listener.isOnline_flag()){
            if (board_listener.isRegret_flag() || board_listener.isStartover_flag()) {
                chess_utils.show_dialog("正在处理请求");
            } else if (JOptionPane.showConfirmDialog(null, "请确定重新开始本局", "提示", JOptionPane.YES_NO_OPTION) == 0) {
                try {
                    dataOutputStream.writeInt(START_OVER_REQUEST);
                    dataOutputStream.flush();
                    board_listener.setStartover_flag(true);
                } catch (IOException ex) {
                    throw new RuntimeException(ex);
                }
            }
        }
        else{
            chess_utils.show_dialog("请先选择游戏模式并开启一局游戏");
        }


    }
}
