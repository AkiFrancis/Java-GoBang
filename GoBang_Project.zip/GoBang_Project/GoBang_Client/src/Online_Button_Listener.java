import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import java.util.Stack;

public class Online_Button_Listener implements ActionListener, GoBang_Consts {
    Chess_Utils chess_utils = new Chess_Utils();
    Chess_Board_Listener board_listener = GoBang_Consts.board_listener;
    Chess_Map chess_map = GoBang_Consts.chess_map;
    private final int[][] map = chess_map.getChess_map();
    static Socket socket = GoBang_Consts.socket;
    private final Stack<int[]> chess_flow = GoBang_Consts.chess_flow;

    Regret_Button_Listener regret_button_listener = GoBang_Consts.regret_button_listener;
    Startover_Button_Listener startoverButtonListener = GoBang_Consts.startover_button_listener;
    private DataOutputStream dataOutputStream;

    @Override
    public void actionPerformed(ActionEvent e) {
        if (board_listener.isOnline_flag()) {
            chess_utils.show_dialog("当前已处于联机模式");
        } else {
            //是否在单机模式
            if (board_listener.getOffline_flag()) {
                //是 返回0  否 返回1
                if (JOptionPane.showConfirmDialog(null, "当前正处于单机模式，若确定将放弃本棋局，创建联机棋局", "提示", JOptionPane.YES_NO_OPTION) == 0) {
                    chess_utils.start_over();
                    //更新模式标志位
                    board_listener.setOnline_flag(true);
                    board_listener.setOffline_flag(false);

                    chess_utils.show_dialog("联机模式开启成功，连接到对手");
                    //创建线程用于通信
                    if (!board_listener.isThread_flag())
                        create_thread();
                }
            } else {
                //更新模式标志位
                board_listener.setOnline_flag(true);
                board_listener.setOffline_flag(false);

                chess_utils.show_dialog("正在连接到对手");
                //创建线程用于通信
                if (!board_listener.isThread_flag())
                    create_thread();
            }
        }
    }

    public void create_thread() {
        new Thread(() -> {
            board_listener.setThread_flag(true);
            DataInputStream dataInputStream;
            try {
                socket = new Socket("localhost", 20000);
                dataInputStream = new DataInputStream(socket.getInputStream());
                dataOutputStream = new DataOutputStream(socket.getOutputStream());
                board_listener.setDataOutputStream(dataOutputStream);
                regret_button_listener.setDataOutputStream(dataOutputStream);
                startoverButtonListener.setDataOutputStream(dataOutputStream);
                exit_button_listener.setDataOutputStream(dataOutputStream);

                board_listener.setConnected(true);
                chess_utils.show_dialog("已连接到对手，对方先落子");
            } catch (IOException ex) {
                throw new RuntimeException(ex);
            }
            while (true) {
                try {
                    int cmd = dataInputStream.readInt();
                    //下棋通信
                    if (cmd == CHESS_MOVE) {
                        int[] pos = new int[2];
                        pos[0] = dataInputStream.readInt();
                        pos[1] = dataInputStream.readInt();
                        chess_map.setChess_map(pos[0], pos[1], 1);
                        chess_flow.push(pos);
                        board_listener.getGraphics().setColor(Color.BLACK);
                        board_listener.draw_online(pos[0], pos[1]);
                        //判断输赢
                        board_listener.judge(chess_map, pos[0], pos[1]);
                        board_listener.setOnline_myturn(true);
                    }
                    //悔棋通信
                    else if (cmd == REGRET_REQUEST) {
                        int i = JOptionPane.showConfirmDialog(null, "对方请求悔棋，是否同意", "提示", JOptionPane.YES_NO_OPTION);
                        //不同意悔棋
                        if (i == 1) {
                            //发送REGRET_REQUEST_DENY
                            dataOutputStream.writeInt(REGRET_REQUEST_DENY);
                            dataOutputStream.flush();
                        }
                        //同意悔棋
                        else {
                            //发送REGRET_REQUEST_APPROVE
                            dataOutputStream.writeInt((REGRET_REQUEST_APPROVE));
                            dataOutputStream.flush();
                            board_listener.setOnline_myturn(false);
                            int[] pos = chess_flow.pop();
                            int chess_flag = map[pos[0]][pos[1]];
                            if (chess_flag > 0) {
                                map[pos[0]][pos[1]] = 0;
                                board_listener.setChess_flag(chess_flag);
                                panel_board.repaint();
                            }
                        }
                    } else if (cmd == REGRET_REQUEST_DENY) {
                        chess_utils.show_dialog("对方不同意悔棋");
                        board_listener.setRegret_flag(false);
                    } else if (cmd == REGRET_REQUEST_APPROVE) {
                        chess_utils.show_dialog("对方同意悔棋");
                        board_listener.setOnline_myturn(true);
                        board_listener.setRegret_flag(false);
                        int[] pos = chess_flow.pop();
                        int chess_flag = map[pos[0]][pos[1]];
                        if (chess_flag > 0) {
                            map[pos[0]][pos[1]] = 0;
                            board_listener.setChess_flag(chess_flag);
                            panel_board.repaint();
                        }

                        board_listener.setOnline_myturn(true);

                    } else if (cmd == START_OVER_REQUEST) {
                        int i = JOptionPane.showConfirmDialog(null, "对方请求重新开始，是否同意", "提示", JOptionPane.YES_NO_OPTION);
                        if (i == 1) {
                            dataOutputStream.writeInt(START_OVER_REQUEST_DENY);
                            dataOutputStream.flush();
                        } else {
                            dataOutputStream.writeInt(START_OVER_REQUEST_APPROVE);
                            dataOutputStream.flush();
                            chess_utils.start_over();
                        }
                    } else if (cmd == START_OVER_REQUEST_DENY) {
                        chess_utils.show_dialog("对方不同意重新开始");
                        board_listener.setStartover_flag(false);
                    } else if (cmd == START_OVER_REQUEST_APPROVE) {
                        chess_utils.start_over();
                    }
                    else if(cmd==8){
                        if(board_listener.isConnected()){
                            dataOutputStream.writeInt(8);
                            dataOutputStream.flush();
                        }
                        dataOutputStream.close();
                        dataInputStream.close();
                        socket.close();
                        board_listener.setConnected(false);
                        board_listener.setThread_flag(false);
                        board_listener.setOnline_flag(false);
                        break;
                    }

                } catch (IOException ex) {
                    throw new RuntimeException(ex);
                }
            }
        }).start();
    }
}


