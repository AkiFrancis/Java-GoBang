

import java.io.DataOutputStream;
import java.net.Socket;
import java.util.Stack;

public interface GoBang_Consts {
    //棋盘常量
    int X = 50, Y = 50, SIZE = 50, ROW_NUM = 15, COL_NUM = 15;

    //保存棋谱常量
    int SAVE_SUCCESS = 1, SAVE_FAIL = 2;

    //通信间的常量
    int CHESS_MOVE = 1, REGRET_REQUEST = 2, REGRET_REQUEST_DENY = 3, REGRET_REQUEST_APPROVE = 4, START_OVER_REQUEST = 5, START_OVER_REQUEST_DENY = 6, START_OVER_REQUEST_APPROVE = 7;


    Chess_Map chess_map = new Chess_Map();

    Stack<int[]> chess_flow = new Stack<>();

    Chessboard_Panel panel_board = new Chessboard_Panel();

    Chess_Board_Listener board_listener = new Chess_Board_Listener();

    Next_Button_Listener next_button_listener = new Next_Button_Listener();

    Regret_Button_Listener regret_button_listener = new Regret_Button_Listener();

    Startover_Button_Listener startover_button_listener = new Startover_Button_Listener();

    Exit_Button_Listener exit_button_listener = new Exit_Button_Listener();
    Socket socket = null;


}
