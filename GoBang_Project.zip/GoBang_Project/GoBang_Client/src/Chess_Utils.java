import javax.swing.*;
import java.io.*;
import java.util.Stack;

public class Chess_Utils implements GoBang_Consts {
    Chess_Map chess_map=GoBang_Consts.chess_map;
    Stack<int[]> chess_flow =GoBang_Consts.chess_flow;
    Chessboard_Panel panel_board=GoBang_Consts.panel_board;
    Chess_Board_Listener board_listener=GoBang_Consts.board_listener;
    //校准落子
    public int[] calibrate(int x, int y) {
        System.out.println(x+"-"+y);
        x = ((x - X / 2) / X) * X;
        y = ((y - Y / 2) / Y) * Y;
        int[] res = new int[2];
        res[0] = x/50;
        res[1] = y/50;
        return res;
    }

    public void show_dialog(String s){
        JOptionPane.showMessageDialog(null, s);
    }
     //0 - 无赢
    // 1 - 黑赢
    // 2 - 白赢
    public int judge_if_win(int[][] chess_map,int x,int y){
        int flag=chess_map[x][y];
        //int tmp_x=x,tmp_y=y;
        int count=1;
        //横向 左
        for(int i=x-1;i>x-5 && i>=0;i--){
            if(chess_map[i][y]==flag){
                count++;
            }
            else{
                break;
            }
        }
        //横向 右
        for(int i=x+1;i<x+5 && i<16;i++){
            if(chess_map[i][y]==flag){
                count++;
            }
            else{
                break;
            }
        }
        if(count>=5){
            return flag;
        }
        else count=1;

        //竖向 上
        for(int j=y-1;j>y-5 && j>=0;j--){
            if(chess_map[x][j]==flag){
                count++;
            }
            else{
                break;
            }
        }
        //竖向 下
        for(int j=y+1;j<y+5 && j<16;j++){
            if(chess_map[x][j]==flag){
                count++;
            }
            else{
                break;
            }
        }
        if(count>=5){
            return flag;
        }
        else {
            count=1;
        }

        //斜向 左上
        int tmp=1;
        while(tmp<5 && x-tmp>=0 && y-tmp>=0){
            int i=x-tmp,j=y-tmp;
            if(chess_map[i][j]==flag){
                count++;
                tmp++;
            }
            else{
                tmp=1;
                break;
            }
        }
        //斜向 右下
        while(tmp<5 && x+tmp<16 && y+tmp<16){
            int i=x+tmp,j=y+tmp;
            if(chess_map[i][j]==flag){
                count++;
                tmp++;
            }
            else{
                tmp=1;
                break;
            }
        }
        if(count>=5){
            return flag;
        }
        else {
            count=1;
        }

        //斜向 左下
        while(tmp<5 && x-tmp>=0 && y+tmp<16){
            int i=x-tmp,j=y+tmp;
            if(chess_map[i][j]==flag){
                count++;
                tmp++;
            }
            else{
                tmp=1;
                break;
            }
        }
        //斜向 右上
        while(tmp<5 && x+tmp<16 && y-tmp>=0){
            int i=x+tmp,j=y-tmp;
            if(chess_map[i][j]==flag){
                count++;
                tmp++;
            }
            else{
                break;
            }
        }
        if(count>=5){
            return flag;
        }
        else {
            return 0;
        }

    }

    public void start_over(){
        //步骤stack清空
        chess_flow.clear();
        //重置chess_map
        for(int i=0;i<16;i++){
            for(int j=0;j<16;j++){
                chess_map.setChess_map(i,j,0);
            }
        }
        board_listener.setChess_flag(1);
        //board_listener.setOffline_flag(true);
        board_listener.setWin_flag(0);
        board_listener.setReview_flag(false);
        board_listener.setOnline_myturn(false);
        board_listener.setStartover_flag(false);
        board_listener.setRegret_flag(false);
        panel_board.repaint();
    }

    public  void save_map(int[][] a, String path) throws IOException {
        //输出流
        FileWriter writer;
        File file=new File(path);
        if(!file.exists()){
            file.createNewFile();
        }
        //实例化输出流
        writer = new FileWriter(file);
        for (int i = 0; i < 16; i++) {
            for (int j = 0; j < 15; j++) {
                writer.write(a[i][j] + ",");
            }
            //结尾
            writer.write(a[i][15] + "");
            writer.write("\n");
        }
        writer.flush();
        writer.close();
    }

    public int[][] read_map(String path) throws IOException {
        //文件读取流实例化 path
        FileReader reader=new FileReader(path);
        //读取缓冲区包装文件输入流
        BufferedReader bufferedReader=new BufferedReader(reader);
        int[][] a=new int[16][16];

        String lineStr;
        for(int i=0;i<16;i++){
            lineStr =bufferedReader.readLine();
            String[] split_str=lineStr.split(",");
            for(int j=0;j<16;j++){
                a[i][j]=Integer.parseInt(split_str[j]);
            }
        }
        reader.close();
        bufferedReader.close();
        return a;
    }

    public int save_flow(Stack<int[]> chess_flow, String path) throws IOException {
        int n=chess_flow.size();

        //输出流
        FileWriter writer;
        File file=new File(path);
        if(!file.exists()){
            if(file.createNewFile()) {
                //实例化输出流
                writer = new FileWriter(file);
                for (int i = 0; i < n; i++) {
                    int[] tmp = chess_flow.pop();
                    writer.write(tmp[0] + "," + tmp[1]);
                    writer.write("\n");
                }
                writer.flush();
                writer.close();
                return SAVE_SUCCESS;
            }
            else{
                return SAVE_FAIL;
            }
        }
        else{
            int o = JOptionPane.showConfirmDialog(null,"该文件已存在，是否覆盖","提示",JOptionPane.YES_NO_OPTION);
            if(o==JOptionPane.YES_OPTION){
                writer = new FileWriter(file);
                for (int i = 0; i < n; i++) {
                    int[] tmp = chess_flow.pop();
                    writer.write(tmp[0]+","+tmp[1]);
                    writer.write("\n");
                }
                writer.flush();
                writer.close();
                return SAVE_SUCCESS;
            }
            return SAVE_FAIL;
        }
    }
    public Stack<int[]> read_flow(String path) throws IOException {
        FileReader reader=new FileReader(path);
        BufferedReader bufferedReader=new BufferedReader(reader);
        Stack<int[]> flow =new Stack<>();
        String lineStr;
        while((lineStr =bufferedReader.readLine())!=null){
            String[] split_str=lineStr.split(",");
            int[] a = new int[2];
            a[0]=Integer.parseInt(split_str[0]);
            a[1]=Integer.parseInt(split_str[1]);
            flow.push(a);
        }
        reader.close();
        bufferedReader.close();
        return flow;
    }

}
