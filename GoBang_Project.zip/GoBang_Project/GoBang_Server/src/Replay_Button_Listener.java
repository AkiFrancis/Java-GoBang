import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.Stack;

public class Replay_Button_Listener implements ActionListener, GoBang_Consts {
    Stack<int[]> chess_flow = GoBang_Consts.chess_flow;
    Chess_Board_Listener board_listener = GoBang_Consts.board_listener;
    Chess_Utils chess_utils = new Chess_Utils();

    @Override
    public void actionPerformed(ActionEvent e) {
        if(board_listener.isOnline_flag()){
            chess_utils.show_dialog("联机模式下不可回放棋谱");
        }
        else{
            String name = "";
            while (name.equals("")) {
                name = JOptionPane.showInputDialog(null, "请输入要读取的棋谱名：");
                if (name == null) {
                    break;
                } else if (name.equals("")) {
                    chess_utils.show_dialog("名字不能为空");
                } else {
                    try {
                        //重置棋盘
                        chess_utils.start_over();
                        Stack<int[]> stack = chess_utils.read_flow("chess_logs\\"+name+".txt");
                        Stack<int[]> stack1 = new Stack<>();
                        while (!stack.empty()) {
                            stack1.push(stack.pop());
                        }
                        while ((!stack1.empty())) {
                            chess_flow.push(stack1.pop());
                        }
                        board_listener.setReview_flag(true);
                        chess_utils.show_dialog("读取成功，点击下一步行棋");

                    } catch (IOException ex) {
                        throw new RuntimeException(ex);
                    }
                }
            }
        }
    }
}
