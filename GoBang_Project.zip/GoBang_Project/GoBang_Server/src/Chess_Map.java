public class Chess_Map {
    private int[][] chess_map = new int[16][16];
    Chess_Map(){
        for(int i=0;i<16;i++){
            for (int j=0;j<16;j++){
                chess_map[i][j]=0;
            }
        }
    }
    public void chess_map_reset(){
        for(int i=0;i<16;i++){
            for (int j=0;j<16;j++){
                chess_map[i][j]=0;
            }
        }
    }
    public int[][] getChess_map() {
        return chess_map;
    }

    public void setChess_map(int x,int y, int v) {
        this.chess_map[x][y]=v;
    }
    public void setChess_map(int[][] x) {
        this.chess_map=x;
    }
    //判断该位置是否为空
    public boolean map_pos_empty(int x , int y){
        if(chess_map[x][y]==0){
            return true;
        }
        return false;
    }


}
