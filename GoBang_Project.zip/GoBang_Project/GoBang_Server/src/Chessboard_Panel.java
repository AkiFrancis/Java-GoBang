import javax.swing.*;
import java.awt.*;

public class Chessboard_Panel extends JPanel implements GoBang_Consts{
    private final Chess_Map chess_map=GoBang_Consts.chess_map;

    private final int[][] map = chess_map.getChess_map();
    @Override
    public void paint(Graphics g) {
        super.paint(g);
        g.setColor (new Color(187, 149, 11));
        g.fillRect (0, 0, getWidth (), getHeight ());
        g.setColor (Color.WHITE);
        // 网格
        for(int i = 0; i < ROW_NUM + 1; i++){
            // 横线
            g.drawLine (X, Y + i * SIZE, X + COL_NUM * SIZE, Y + i * SIZE);
            // 竖线
            g.drawLine (X + i * SIZE, Y, X + i * SIZE, Y + ROW_NUM * SIZE);
        }

        for(int i=0;i<16;i++){
            for(int j=0;j<16;j++){
                if(map[i][j]==1){
                    g.setColor(Color.BLACK);
                    g.fillOval(i*50 + X / 2 +5, j*50 + Y / 2 +5, 40, 40);
                }
                else if(map[i][j]==2){
                    g.setColor(Color.WHITE);
                    g.fillOval(i*50 + X / 2 +5, j*50 + Y / 2 +5, 40, 40);
                }
            }
        }

    }

}
