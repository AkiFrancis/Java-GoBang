import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.DataOutputStream;
import java.io.IOException;

public class Exit_Button_Listener implements ActionListener,GoBang_Consts{
    Chess_Board_Listener board_listener=GoBang_Consts.board_listener;
    Chess_Utils chess_utils=new Chess_Utils();
    public void setDataOutputStream(DataOutputStream dataOutputStream) {
        this.dataOutputStream = dataOutputStream;
    }

    private DataOutputStream dataOutputStream;
    @Override
    public void actionPerformed(ActionEvent e) {
        if(board_listener.isConnected()){
            try {
                dataOutputStream.writeInt(8);
                dataOutputStream.flush();

                board_listener.setConnected(false);
            } catch (IOException ex) {
                throw new RuntimeException(ex);
            }

        }
    }
}
