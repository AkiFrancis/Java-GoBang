import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class GoBang_Server {
    private final int port=20000;
    private final ServerSocket serverSocket;

    GoBang_Server(){
        try {
            serverSocket=new ServerSocket(port);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public Socket listen(){
        try {
            return serverSocket.accept();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }



    }



}
