
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.Stack;

public class Chess_Board_Listener implements MouseListener, GoBang_Consts {

    public void setGraphics(Graphics graphics) {
        this.graphics = graphics;
    }

    public Graphics getGraphics() {
        return graphics;
    }

    private Graphics graphics;
    private final Chess_Utils chess_utils = new Chess_Utils();

    private final Chess_Map chess_map = GoBang_Consts.chess_map;
    private final Stack<int[]> chess_flow = GoBang_Consts.chess_flow;

    public void setChess_flag(int chess_flag) {
        this.chess_flag = chess_flag;
    }

    //flag:1黑 2白 0无
    private int chess_flag = 1;

    public boolean getOffline_flag() {
        return offline_flag;
    }

    public void setOffline_flag(boolean offline_flag) {
        this.offline_flag = offline_flag;
    }

    private boolean offline_flag = false;

    public void setWin_flag(int win_flag) {
        this.win_flag = win_flag;
    }

    public int getWin_flag() {
        return win_flag;
    }

    private int win_flag = 0;

    public boolean isReview_flag() {
        return review_flag;
    }

    public void setReview_flag(boolean review_flag) {
        this.review_flag = review_flag;
    }

    private boolean review_flag = false;


    public boolean isThread_flag() {
        return thread_flag;
    }

    public void setThread_flag(boolean thread_flag) {
        this.thread_flag = thread_flag;
    }

    private boolean thread_flag=false;

    public boolean isRegret_flag() {
        return regret_flag;
    }

    public void setRegret_flag(boolean regret_flag) {
        this.regret_flag = regret_flag;
    }

    private boolean regret_flag = false;

    public boolean isOnline_flag() {
        return online_flag;
    }

    public void setOnline_flag(boolean online_flag) {
        this.online_flag = online_flag;
    }

    private boolean online_flag = false;


    public boolean isStartover_flag() {
        return startover_flag;
    }

    public void setStartover_flag(boolean startover_flag) {
        this.startover_flag = startover_flag;
    }

    private boolean startover_flag = false;


    public boolean isConnected() {
        return connected;
    }

    public void setConnected(boolean connected) {
        this.connected = connected;
    }

    private boolean connected = false;


    public void setDataOutputStream(DataOutputStream dataOutputStream) {
        this.dataOutputStream = dataOutputStream;
    }

    public DataOutputStream getDataOutputStream() {
        return dataOutputStream;
    }

    private DataOutputStream dataOutputStream;


    private boolean online_myturn = true;

    public boolean isOnline_myturn() {
        return online_myturn;
    }

    public void setOnline_myturn(boolean online_myturn) {
        this.online_myturn = online_myturn;
    }

    //松开鼠标在目标处落子
    @Override
    public void mouseReleased(MouseEvent e) {
        //单机模式
        int[] pos;

        if (!online_flag) {
            //获取点击坐标
            if (offline_flag && win_flag == 0 && !review_flag) {
                int x = e.getX();
                int y = e.getY();

                //超出棋盘范围不可落子
                if (x >= 25 && x <= 825 && y >= 25 && y <= 825) {
                    pos = chess_utils.calibrate(x, y);
                    //点击处无子
                    if (chess_map.map_pos_empty(pos[0], pos[1])) {
                        chess_map.setChess_map(pos[0], pos[1], chess_flag);
                        //绘制棋子
                        draw_offline(pos[0], pos[1]);
                        //按序加入chess_flow
                        chess_flow.push(pos);
                        //每下一步棋都要判断输赢
                        judge(chess_map, pos[0], pos[1]);
                    }
                    //点击处有子
                    else {
                        chess_utils.show_dialog("该处已有子");
                    }
                }
            } else {
                if (!offline_flag) {
                    chess_utils.show_dialog("请点击开始游戏");
                }
                if (win_flag != 0) {
                    chess_utils.show_dialog("请点击重新开始");
                }
                if (review_flag) {
                    chess_utils.show_dialog("正在复盘，无法落子");
                }
            }
        }
        //联机模式
        else {
            //还未连接
            if (!connected) {
                chess_utils.show_dialog("还没有对手连接到对局，请耐心等待");
            } else {
                if (win_flag == 0 && !review_flag && online_myturn && !regret_flag && !startover_flag) {
                    int x = e.getX();
                    int y = e.getY();

                    //超出棋盘范围不可落子
                    if (x >= 25 && x <= 825 && y >= 25 && y <= 825) {
                        pos = chess_utils.calibrate(x, y);
                        //落子 信息存入map
                        //点击处无子
                        if (chess_map.map_pos_empty(pos[0], pos[1])) {
                            chess_map.setChess_map(pos[0], pos[1], chess_flag);
                            //绘制棋子
                            graphics.setColor(Color.BLACK);
                            draw_online(pos[0], pos[1]);
                            //按序加入chess_flow
                            chess_flow.push(pos);
                            //每下一步棋都要判断输赢
                            judge(chess_map, pos[0], pos[1]);
                            try {
                                dataOutputStream.writeInt(1);
                                dataOutputStream.writeInt(pos[0]);
                                dataOutputStream.writeInt(pos[1]);
                                dataOutputStream.flush();
                                online_myturn = false;

                            } catch (IOException ex) {
                                throw new RuntimeException(ex);
                            }

                        }
                        //点击处有子
                        else {
                            chess_utils.show_dialog("该处已有子");
                        }
                    }
                } else {
                    if(win_flag!=0){
                        chess_utils.show_dialog("请点击重新开始");
                    }
                    else if (!online_myturn) {
                        chess_utils.show_dialog("轮到对方落子，请耐心等待");
                    }

                    else if(regret_flag){
                        chess_utils.show_dialog("正在请求悔棋，请耐心等待");
                    }
                    else if(startover_flag){
                        chess_utils.show_dialog("正在请求重新开始，请耐心等待");
                    }
                }
            }
        }
    }


    public  void judge(Chess_Map chess_map,int x,int y){
        win_flag = chess_utils.judge_if_win(chess_map.getChess_map(), x, y);
        if (win_flag != 0) {
            //黑赢
            if (win_flag == 1) {
                chess_utils.show_dialog("执黑者赢");
            }
            //白赢
            else if (win_flag == 2) {
                chess_utils.show_dialog("执白者赢");
            }
        }
    }

    public void draw_offline(int x, int y){
        if (chess_flag == 1) {
            graphics.setColor(Color.BLACK);
            chess_flag = 2;
        } else if (chess_flag == 2) {
            graphics.setColor(Color.WHITE);
            chess_flag = 1;
        }
        graphics.fillOval(x*50 + X / 2 + 5, y*50 + Y / 2 + 5, 40, 40);
    }
    public void draw_online(int x,int y){
        graphics.fillOval(x*50 + X / 2 + 5, y*50 + Y / 2 + 5, 40, 40);
    }




    @Override
    public void mouseClicked(MouseEvent e) {


    }

    @Override
    public void mousePressed(MouseEvent e) {

    }


    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }


}
