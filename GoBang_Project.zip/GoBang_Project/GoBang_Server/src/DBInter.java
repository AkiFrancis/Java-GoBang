public interface  DBInter {


    public boolean saveObj(Object data);



    public   Object get(int id);

    // sql:  seletct *  from userTable where name=?
    public  Object parseSql(String sqlGet);



    // file frame格式









}
