import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.Socket;

public class Offline_Button_Listener implements ActionListener,GoBang_Consts{
    Chess_Board_Listener board_listener=GoBang_Consts.board_listener;
    Chess_Utils chess_utils=new Chess_Utils();

    Socket socket=GoBang_Consts.socket;
    @Override
    public void actionPerformed(ActionEvent e) {
        if(!board_listener.getOffline_flag()){
            if(board_listener.isOnline_flag()){
                if(JOptionPane.showConfirmDialog(null,"当前正处于联机模式，若确定将放弃本棋局，创建单机棋局","提示",JOptionPane.YES_NO_OPTION)==0){
                    chess_utils.start_over();
                    board_listener.setOffline_flag(true);
                    board_listener.setOnline_flag(false);
                    chess_utils.show_dialog("单机模式开启成功");
                }
            }
            else {
                board_listener.setOffline_flag(true);
                board_listener.setOnline_flag(false);
                chess_utils.show_dialog("单机模式开启成功");
            }
        }
        else{
            chess_utils.show_dialog("当前已处于单机模式");
        }
    }
}
