

public class test {
    public static void main(String[] args) {
        GoBang_UI ui = new GoBang_UI();
        ui.Create_UI();
    }
}
