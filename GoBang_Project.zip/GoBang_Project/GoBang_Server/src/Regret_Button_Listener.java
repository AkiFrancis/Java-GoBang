import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.Stack;

public class Regret_Button_Listener implements ActionListener,GoBang_Consts {
    private final Chess_Map chess_map = GoBang_Consts.chess_map;
    private final Chessboard_Panel panel_board = GoBang_Consts.panel_board;
    private final Stack<int[]> chess_flow = GoBang_Consts.chess_flow;
    private final int[][] map = chess_map.getChess_map();
    private final Chess_Board_Listener board_listener = GoBang_Consts.board_listener;
    private final Chess_Utils chess_utils=new Chess_Utils();

    public void setDataOutputStream(DataOutputStream dataOutputStream) {
        this.dataOutputStream = dataOutputStream;
    }

    private DataOutputStream dataOutputStream;


    @Override
    public void actionPerformed(ActionEvent e) {
        //单机模式
        if(board_listener.getOffline_flag()){
            //已经下过 并且一局未结束 并且不在复盘 可悔棋
            if (!chess_flow.empty() && board_listener.getWin_flag() == 0 && !board_listener.isReview_flag()) {
                int[] pos = chess_flow.pop();
                int chess_flag = map[pos[0]][pos[1]];
                if (chess_flag > 0) {
                    map[pos[0]][pos[1]] = 0;
                    board_listener.setChess_flag(chess_flag);
                    panel_board.repaint();
                }
            }
            //本局已结束
            else {
                if(chess_flow.empty()){
                    JOptionPane.showMessageDialog(null, "您已无棋可悔");
                }
                if (board_listener.getWin_flag() != 0) {
                    JOptionPane.showMessageDialog(null, "本局游戏已结束");
                }
                if(board_listener.isReview_flag()){
                    JOptionPane.showMessageDialog(null, "正在复盘，不能悔棋");
                }
            }
        }

        //联机模式
        else if(board_listener.isOnline_flag()){
            //到我下了 不能悔棋
            if(board_listener.isOnline_myturn() || board_listener.getWin_flag()!=0 || chess_flow.empty() || board_listener.isStartover_flag() || board_listener.isRegret_flag()){
                chess_utils.show_dialog("当前不可悔棋");
            }
            else{
                try {
                    board_listener.setRegret_flag(true);
                    dataOutputStream.writeInt(REGRET_REQUEST);
                    dataOutputStream.flush();
                } catch (IOException ex) {
                    throw new RuntimeException(ex);
                }
            }



        }


    }
}
