import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.Objects;
import java.util.Stack;

public class Save_Button_Listener implements ActionListener,GoBang_Consts {
    Stack<int[]> chess_flow =GoBang_Consts.chess_flow;
    Chess_Utils chess_utils= new Chess_Utils();

    @Override
    public void actionPerformed(ActionEvent e) {
        String name="";
        int n=SAVE_FAIL;
        while(Objects.equals(name, "") || n==SAVE_FAIL){
            name = JOptionPane.showInputDialog("请输入保存棋谱名:");
            if(name==null){
                break;
            }
            else if(name.equals("")){
                chess_utils.show_dialog("名字不能为空");
            }
            else {
                try {
                    n = chess_utils.save_flow(chess_flow, "chess_logs\\"+name+".txt");
                    if(n==SAVE_SUCCESS){
                        chess_utils.show_dialog("已保存");
                    }
                    else{
                        chess_utils.show_dialog("保存失败");
                    }
                } catch (IOException ex) {
                    throw new RuntimeException(ex);
                }
            }
        }
    }
}
