import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Stack;

public class Next_Button_Listener implements ActionListener,GoBang_Consts {
    Chess_Map chess_map=GoBang_Consts.chess_map;
    Stack<int[]> chess_flow =GoBang_Consts.chess_flow;
    Chess_Board_Listener board_listener=GoBang_Consts.board_listener;

    int chess_flag=1;
    @Override
    public void actionPerformed(ActionEvent e) {
        if(!chess_flow.empty()){
            int[] move = chess_flow.pop();
            int map_x=move[0];
            int map_y=move[1];
            chess_map.setChess_map(map_x, map_y, chess_flag);
            //切换黑白子
            board_listener.draw_offline(map_x,map_y);
        }
        else{
            JOptionPane.showMessageDialog(null, "棋谱已走完，您可继续行棋");
            board_listener.setReview_flag(false);
        }
    }
}
