import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.Scanner;

public class client_test1 {

    public static void main(String[] args) throws IOException {
        Socket socket = new Socket("localhost", 20000);
        DataInputStream dataInputStream = new DataInputStream(socket.getInputStream());
        DataOutputStream dataOutputStream = new DataOutputStream(socket.getOutputStream());
        Scanner sc=new Scanner(System.in);
        while (true) {
            int a = dataInputStream.readInt();
            System.out.println(a);
            if (a == 1) {
                System.out.println("收到 " + a);
                int b = dataInputStream.readInt();
                int c = dataInputStream.readInt();
                System.out.println("坐标 " + b + " " + c);
                //int x = sc.nextInt();
                //int y = sc.nextInt();
                //dataOutputStream.writeInt(1);
                //dataOutputStream.writeInt(x);
                //dataOutputStream.writeInt(y);
                dataOutputStream.flush();

            }
            else if(a==2){
                System.out.println("收到 "+a);
                dataOutputStream.writeInt(3);
                System.out.println("发送 4");

            }


        }
    }
}
