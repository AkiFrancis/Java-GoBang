import javax.swing.*;
import java.awt.*;

public class GoBang_UI {
    Chess_Board_Listener board_listener=GoBang_Consts.board_listener;
    Next_Button_Listener next_button_listener=GoBang_Consts.next_button_listener;
    Regret_Button_Listener regret_button_listener =GoBang_Consts.regret_button_listener;
    Startover_Button_Listener startover_button_listener=GoBang_Consts.startover_button_listener;
    Exit_Button_Listener exit_button_listener=GoBang_Consts.exit_button_listener;
    public void Create_UI(){
        //窗体
        JFrame jf_ui = new JFrame("五子棋-server");
        jf_ui.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
        jf_ui.setSize (1100, 900);
        jf_ui.setLocationRelativeTo (null);
        jf_ui.setResizable (false);
        jf_ui.setLayout (new BorderLayout());

        //棋盘面板
        Chessboard_Panel panel_board=GoBang_Consts.panel_board;
        panel_board.setLayout(null);

        //按键面板
        JPanel panel_button=new JPanel();
        panel_button.setBackground(Color.ORANGE);
        panel_button.setPreferredSize(new Dimension(200,0));

        //开始游戏 按键
        JButton button_start = new JButton("单机游戏");
        button_start.setBackground(Color.WHITE);
        button_start.setPreferredSize(new Dimension(125,50));
        button_start.addActionListener(new Offline_Button_Listener());
        panel_button.add(button_start);
        //联机游戏按键
        JButton button_online = new JButton("联机游戏");
        button_online.setBackground(Color.WHITE);
        button_online.setPreferredSize(new Dimension(125,50));
        button_online.addActionListener(new Online_Button_Listener());
        panel_button.add(button_online);
        //悔棋按键
        JButton button_regret = new JButton("悔棋");
        button_regret.setBackground(Color.WHITE);
        button_regret.setPreferredSize(new Dimension(125,50));
        button_regret.addActionListener(regret_button_listener);
        panel_button.add(button_regret);
        //重新开始 按键
        JButton button_startover = new JButton("重新开始");
        button_startover.setBackground(Color.WHITE);
        button_startover.setPreferredSize(new Dimension(125,50));
        button_startover.addActionListener(startover_button_listener);
        panel_button.add(button_startover);
        //存档 按键
        JButton button_save = new JButton("保留本局棋谱");
        button_save.setBackground(Color.WHITE);
        button_save.setPreferredSize(new Dimension(125,50));
        button_save.addActionListener(new Save_Button_Listener());
        panel_button.add(button_save);
        //回放 按键
        JButton button_replay = new JButton("回放棋谱");
        button_replay.setBackground(Color.WHITE);
        button_replay.setPreferredSize(new Dimension(125,50));
        button_replay.addActionListener(new Replay_Button_Listener());
        panel_button.add(button_replay);
        //下一步 按键
        JButton button_next = new JButton("下一步");
        button_next.setBackground(Color.WHITE);
        button_next.setPreferredSize(new Dimension(125,50));
        button_next.addActionListener(next_button_listener);
        panel_button.add(button_next);
        //退出 按键
        JButton button_exit = new JButton("断开连接");
        button_exit.setBackground(Color.WHITE);
        button_exit.setPreferredSize(new Dimension(125,50));
        button_exit.addActionListener(exit_button_listener);
        panel_button.add(button_exit);



        jf_ui.add(panel_button,BorderLayout.EAST);
        jf_ui.add(panel_board,BorderLayout.CENTER);
        System.out.println(panel_board);
        jf_ui.setVisible(true);

        //如果在组件可见前getGraphics会返回null
        panel_board.addMouseListener(board_listener);
        board_listener.setGraphics(panel_board.getGraphics());

    }





}
